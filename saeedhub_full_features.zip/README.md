SaeedHub — Full Features Frontend (Firebase-backed)

This package contains a ready-to-deploy frontend for SaeedHub with:
- Video posts, image posts, text posts
- Stories (short-lived), likes, comments
- Private messaging (Firestore)
- Voice recording & upload (browser MediaRecorder)

Instructions:
1. Create Firebase project and enable Auth (Google), Firestore, Storage.
2. Copy Firebase web config into public/firebase-config.js (rename from example).
3. Deploy public/ folder to Vercel/Netlify or upload to GitHub and connect to Vercel.
4. Set Firestore and Storage rules before production.
